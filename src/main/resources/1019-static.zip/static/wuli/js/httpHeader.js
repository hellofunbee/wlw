var http = "http://120.132.53.44:8087/";
/*var http = "http://192.168.0.206:8087/";*/
/*var http = "/";*/