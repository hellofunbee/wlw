$(function(){
	var str='<div class="picHave"><span></span></div>';
	$('body').append(str);
})
